angular.module('myApp')
  .service('SharedService', [function(){
    var name = "名無し";

    this.getName = function(){ return name;}  

    this.setName = function(newName){
      name = newName;
    };
  }])
  .controller('FirstController', ['$scope', 'SharedService', function($scope, SharedService) {
    $scope.onChange = function(){
        SharedService.setName($scope.loginName);};
  }])
  .controller('SecondController', ['$scope', 'SharedService', function($scope, SharedService) {
    $scope.loginName = SharedService.getName();
  }])

