angular.module('myApp', [ 'ngRoute' ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/first.html',
        controller: 'FirstController'
      })
      .when('/second', {
        templateUrl: 'views/second.html',
        controller: 'SecondController'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
