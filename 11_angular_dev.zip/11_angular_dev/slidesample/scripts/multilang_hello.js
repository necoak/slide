angular.module('myApp', [])
.service('MyService', [function(){
	var langs = [
		{id: "jp", name: "Japanese"},
		{id: "en", name: "English"}];

	this.getLangs = function(){	return langs;}	

  	this.getGreetMsg = function(lang){
  		if (lang.id === "jp"){ return "こんにちは！";}
  		else { return "Hello!"; }
  	};
}])
.controller('MyController', ['$scope', 'MyService', function($scope, MyService) {
	$scope.langs = MyService.getLangs();
  	$scope.onChange = function(){
	    $scope.greetMsg = MyService.getGreetMsg($scope.selectedLang);
	};
  }])
